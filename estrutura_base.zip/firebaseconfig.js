// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAHOtjO_NlDd4SuSiPCFH8wSpk5AxCOMCE",
  authDomain: "app-habla-mobile.firebaseapp.com",
  projectId: "app-habla-mobile",
  storageBucket: "app-habla-mobile.firebasestorage.app",
  messagingSenderId: "1080185382553",
  appId: "1:1080185382553:web:1a7d639cc0caa22ad57a08"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);